const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');

function paypalClient() {
  return new checkoutNodeJssdk.core.PayPalHttpClient(
    new checkoutNodeJssdk.core.SandboxEnvironment(
      process.env.PAYPAL_CLIENT_ID,
      process.env.PAYPAL_CLIENT_SECRET
    )
  );
}

module.exports = { paypalClient };