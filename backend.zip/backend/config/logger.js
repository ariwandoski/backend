// utils/logger.js
const pino = require('pino');

const isDev = process.env.NODE_ENV !== 'production';

// Pretty print only in development (colorful console)
const prettyOptions = isDev
  ? {
      colorize: true,
      translateTime: 'SYS:standard', // nice timestamp
      ignore: 'pid,hostname',        // clean output
      messageFormat: '{msg} {context}', // optional
    }
  : false;

const logger = pino(
  {
    level: process.env.LOG_LEVEL || 'info',
    redact: ['req.headers.authorization', 'password', 'token'],
  },
  pino.multistream([
    // Console (pretty in dev)
    { level: isDev ? 'debug' : 'info', stream: pino.destination(1) },
    // File in production
    isDev
      ? undefined
      : {
          level: 'info',
          stream: pino.destination({
            dest: './logs/app.log',
            sync: false,
            mkdir: true,
            append: true,
          }),
        },
  ])
);

// Optional helper methods for common patterns
logger.request = (req) => {
  logger.info({
    method: req.method,
    url: req.originalUrl,
    ip: req.ip,
    userAgent: req.get('user-agent'),
    user: req.user?._id || 'guest',
  }, 'Incoming request');
};

module.exports = logger; 