const multer = require('multer');
const path = require('path');

// Set storage engine
const storage = multer.diskStorage({
    storage,
    limits: { fileSize: 5000000 }, //5MB
    fileFilter: (req, file, cb) => {
        const filetypes = /jpeg|jpg|png|webp/;
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = filetypes.test(file.mimetype);
        if(extname && mimetype) {
            return cb(null, true);
        }
        cb('image only (jpeg, jpg, png webp)');
    },
}).single('image'); // 'image' is the field name from frontend form

module.exports = upload;