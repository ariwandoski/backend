const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema({
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true,
    },
    quantity: {
        type: Number,
        required: true,
        min: 1,
    },
    priceAtAdd: {
        type: Number,
        required: true, // snapshot of price when added (handles price changes)
    },
}, { _id: false }); // no separate _id for subdocs

const cartSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: false,
        unique: true, // one cart per user
    },
    items: [cartItemSchema],
    updatedAt: {
        type: Date,
        default: Date.now,
    },
    sessionId: {
        type: String,
        required: false,
        index: true,
    },
}, { timestamps: true });

// Optional: auto-update timestamp on change
cartSchema.pre('save', function () {
    this.updatedAt = Date.now();
});

module.exports = mongoose.model('Cart', cartSchema);