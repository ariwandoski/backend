const mongoose = require('mongoose');

function generateSlug(name) {
    if (!name) return '';
    return name
        .toString()
        .toLowerCase()
        .trim()
        .replace(/\s+/g, '-')           // Replace spaces with -
        .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
        .replace(/\-\-+/g, '-')         // Replace multiple - with single -
        .replace(/^-+/, '')             // Trim - from start
        .replace(/-+$/, '');            // Trim - from end
}

const reviewSchema = mongoose.Schema(
    {
        name: { type: String, required: true },
        rating: { type: Number, required: true },
        comment: { type: String, required: true },
        user: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: 'User',
        },
    },
    { timestamps: true }
);

const productSchema = mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Please add a product name'],
            trim: true,
        },
        description: {
            type: String,
            required: [true, 'Please add a description'],
        },
        price: {
            type: String,
            required: [true, 'Please add a price'],
            min: 0
        },
        discountPrice: {
            type: Number,
            default: 0, // optional: lower price for promotions/sales
        },
        countInStock: {
            type: Number,
            required: true,
            min: 0,
            default: 0,
        },
        image: {
            type: String,
            required: [true, 'Please add at least one image'],
        },
        images: {
            type: [String], // array of additional image URLs
            default: [],
        },
        category: {
            type: String,
            required: true,
            enum: [
                'Electronics',
                'Fashion',
                'Home & Kitchen',
                'Beauty',
                'Sports',
                'Books',
                'Toys',
                'Other',
            ],
        },
        brand: {
            type: String,
            required: true,
        },
        rating: {
            type: Number,
            default: 0,
            min: 0,
            max: 5,
        },
        numReviews: {
            type: Number,
            default: 0,
        },
        reviews: [reviewSchema], //embedded reviews
        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        isFeatured: {
            type: Boolean,
            default: false,
        },
        slug: {
            type: String,
            unique: true,
            lowercase: true,
            trim: true,
        },
    },
    {
        timestamps: true,
    }
);

// productSchema.index({ price: 1, _id: 1 });
// productSchema.index({ price: -1, _id: -1 });
// productSchema.index({ rating: -1, _id: -1 });
// // productSchema.index({ _id: -1 }); // already exists by default

// When Sorting Price Range
productSchema.index({ countInStock: 1 });
productSchema.index({ price: 1, _id: 1 });
productSchema.index({ price: -1, _id: -1 });
productSchema.index({ category: 1, price: 1, _id: 1 });
productSchema.index({ brand: 1 });
productSchema.index({ rating: -1 });
productSchema.index({ brand: 1, price: 1, _id: 1 }); // useful compound
productSchema.index({ rating: -1, _id: -1 });

// Optional: auto-generate slug from name (before save)
productSchema.pre('save', async function () {
    if (this.isNew || this.isModified('name')) {
        let slug = generateSlug(this.name);
        let count = 0;
        let uniqueSlug = slug;

        // Check if slug exists (exclude current document if updating)
        while (true) {
            const existing = await this.constructor.findOne({
                slug: uniqueSlug,
                _id: { $ne: this._id }, // exclude self when updating
            });

            if (!existing) break;

            count++;
            uniqueSlug = `${slug}-${count}`;
        }

        this.slug = uniqueSlug;
    }
});


module.exports = mongoose.model('Product', productSchema);