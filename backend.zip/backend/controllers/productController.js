const mongoose = require('mongoose');
const Product = require('../models/Product');


// @desc    Get products with cursor-based pagination (for infinite scroll / load more) with price range
// @route   GET /api/products
// @access  Public
const getProducts = async (req, res) => {
    try {
        const limit = Number(req.query.limit) || 12;
        const cursor = req.query.cursor || null;
        const sort = req.query.sort || 'newest';

        // ─── BASE FILTERS ────────────────────────────────────────
        const keyword = req.query.keyword
            ? { name: { $regex: req.query.keyword, $options: 'i' } }
            : {};

        const category = req.query.category ? { category: req.query.category } : {};

        // NEW: In-stock only
        const inStock = req.query.inStock === 'true';
        const stockFilter = inStock ? { countInStock: { $gt: 0 } } : {};

        // NEW: Price range filter
        const minPrice = Number(req.query.minPrice);
        const maxPrice = Number(req.query.maxPrice);

        const priceFilter = {};
        if (!isNaN(minPrice)) priceFilter.$gte = minPrice;
        if (!isNaN(maxPrice)) priceFilter.$lte = maxPrice;

        const priceQuery = Object.keys(priceFilter).length > 0
            ? { price: priceFilter }
            : {};

        // ─── NEW: Brands filter (multiple) ────────────────────────────────
        const brands = req.query.brand
            ? req.query.brand.split(',').map(b => b.trim()).filter(Boolean)
            : [];

        const brandFilter = brands.length > 0 ? { brand: { $in: brands } } : {};

        // ─── NEW: Minimum rating filter ───────────────────────────────────
        const minRating = Number(req.query.minRating);
        const ratingFilter = !isNaN(minRating) && minRating > 0
            ? { rating: { $gte: minRating } }
            : {};

        const featured = req.query.featured === 'true';
        const featuredFilter = featured ? { isFeatured: true } : {};


        // Then combine in query:
        const query = {
            ...keyword,
            ...category,
            ...stockFilter,
            ...priceQuery,
            ...brandFilter,
            ...ratingFilter,
            ...featuredFilter,
        };

        // ─── SORTING ─────────────────────────────────────────────
        let sortField = '_id';
        let sortOrder = -1; // descending

        switch (sort) {
            case 'price-asc':
                sortField = 'price';
                sortOrder = 1;
                break;
            case 'price-desc':
                sortField = 'price';
                sortOrder = -1;
                break;
            case 'rating':
                sortField = 'rating';
                sortOrder = -1;
                break;
            default: // newest
                sortField = '_id';
                sortOrder = -1;
        }

        const sortObj = { [sortField]: sortOrder, _id: sortOrder };

        // ─── CURSOR LOGIC ────────────────────────────────────────
        let cursorValue = null;
        let cursorId = null;

        if (cursor) {
            const decoded = Buffer.from(cursor, 'base64').toString('utf-8');
            const [val, id] = decoded.split('|');
            cursorValue = sortField === '_id' ? id : Number(val);
            cursorId = id;

            if (sortField === '_id') {
                query._id = sortOrder === -1 ? { $lt: cursorValue } : { $gt: cursorValue };
            } else {
                const rangeOp = sortOrder === 1 ? '$gt' : '$lt';
                const tieOp = sortOrder === 1 ? '$gt' : '$lt';

                query.$or = [
                    { [sortField]: { [rangeOp]: cursorValue } },
                    {
                        [sortField]: cursorValue,
                        _id: { [tieOp]: cursorId },
                    },
                ];
            }
        }

        // ─── FETCH DATA ──────────────────────────────────────────
        let products = await Product.find(query)
            .sort(sortObj)
            .limit(limit + 1)
            .lean();

        let hasNextPage = products.length > limit;
        let nextCursor = null;

        if (hasNextPage) {
            const last = products.pop();
            const lastSortValue = sortField === '_id' ? last._id.toString() : last[sortField];
            const composite = `${lastSortValue}|${last._id.toString()}`;
            nextCursor = Buffer.from(composite).toString('base64');
        }

        const total = await Product.countDocuments(query);

        res.json({
            products,
            nextCursor,
            hasNextPage,
            total,                // total after all filters
            currentSort: sort,
            appliedFilters: {
                keyword: req.query.keyword || null,
                category: req.query.category || null,
                inStock: inStock || false,
                minPrice: isNaN(minPrice) ? null : minPrice,
                maxPrice: isNaN(maxPrice) ? null : maxPrice,
                brands: brands.length > 0 ? brands : null,
                minRating: isNaN(minRating) ? null : minRating,
            },
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: 'Failed to fetch products' });
    }
};

// @desc    Get single product by ID (or slug later)
// @route   GET /api/products/:slug 
// @access  Public
const getProductById = async (req, res) => {
    const { slug } = req.params;

    // Try slug first (most common)
    let product = await Product.findOne({ slug });

    // If not found and it looks like an ObjectId, try by _id
    if (!product && mongoose.Types.ObjectId.isValid(slug)) {
        product = await Product.findById(slug);
    }

    if (product) {
        // Optional: redirect to slug URL if someone used ObjectId
        if (mongoose.Types.ObjectId.isValid(slug) && product.slug) {
            return res.redirect(301, `/api/products/${product.slug}`);
        }
        return res.json(product);
    }

    res.status(404);
    throw new Error('Product not found');
};

// @desc    Get all reviews for a product
// @route   GET /api/products/:slug/reviews
// @access  Public
// @desc    Get paginated reviews for a product
// @route   GET /api/products/:slug/reviews
// @access  Public
const getProductReviews = async (req, res) => {
    try {
        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10; // reviews per page
        const skip = (page - 1) * limit;

        const sort = req.query.sort || 'newest';

        let sortStage = { $sort: { 'reviews.createdAt': -1 } }; // newest first

        if (sort === 'rating-desc') {
            sortStage = { $sort: { 'reviews.rating': -1 } };
        } else if (sort === 'rating-asc') {
            sortStage = { $sort: { 'reviews.rating': 1 } };
        }

        const product = await Product.aggregate([
            { $match: { slug: req.params.slug } },
            {
                $project: {
                    reviews: 1,
                    rating: 1,
                    numReviews: 1,
                    totalReviews: { $size: '$reviews' },
                },
            },
            // Unwind reviews array so we can paginate
            { $unwind: { path: '$reviews', preserveNullAndEmptyArrays: true } },
            // Sort after unwind
            sortStage.$sort ? sortStage : { $sort: { 'reviews.createdAt': -1 } },
            // Skip & limit for pagination
            { $skip: skip },
            { $limit: limit },
            // Group back to reconstruct document
            {
                $group: {
                    _id: '$_id',
                    reviews: { $push: '$reviews' },
                    rating: { $first: '$rating' },
                    numReviews: { $first: '$numReviews' },
                    totalReviews: { $first: '$totalReviews' },
                },
            },
            {
                $project: {
                    reviews: 1,
                    averageRating: '$rating',
                    totalReviews: 1,
                    currentPage: page,
                    totalPages: {
                        $ceil: { $divide: ['$totalReviews', limit] },
                    },
                    hasNextPage: {
                        $cond: {
                            if: { $gt: ['$totalReviews', { $add: [skip, limit] }] },
                            then: true,
                            else: false,
                        },
                    },
                },
            },
        ]);

        if (!product || product.length === 0) {
            res.status(404);
            throw new Error('Product not found or no reviews');
        }

        const result = product[0];

        // If no reviews, return empty array safely
        result.reviews = result.reviews || [];

        res.json({
            success: true,
            ...result,
            sortApplied: sort,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch reviews',
        });
    }
};

// @desc    Add a review to a product
// @route   POST /api/products/:slug/reviews
// @access  Private (logged-in user)
const createProductReview = async (req, res) => {
    const { rating, comment } = req.body;

    if (!rating || rating < 1 || rating > 5) {
        res.status(400);
        throw new Error('Rating must be between 1 and 5');
    }

    const product = await Product.findOne({ slug: req.params.slug });

    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    // Check if user already reviewed this product
    const alreadyReviewed = product.reviews.find(
        (r) => r.user.toString() === req.user._id.toString()
    );

    if (alreadyReviewed) {
        res.status(400);
        throw new Error('Product already reviewed by you');
    }

    const review = {
        name: req.user.name,
        rating: Number(rating),
        comment,
        user: req.user._id,
    };

    product.reviews.push(review);

    // ─── RECALCULATE AVERAGE RATING ───────────────────────────────
    const totalRating = product.reviews.reduce((acc, item) => acc + item.rating, 0);
    product.rating = Number((totalRating / product.reviews.length).toFixed(1));
    product.numReviews = product.reviews.length;

    await product.save();

    res.status(201).json({ message: 'Review added successfully' });
};

// @desc    Update user's own review
// @route   PATCH /api/products/:slug/reviews
// @access  Private
const updateProductReview = async (req, res) => {
    const { rating, comment } = req.body;

    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) throw new Error('Product not found');

    const review = product.reviews.find(
        (r) => r.user.toString() === req.user._id.toString()
    );

    if (!review) {
        res.status(404);
        throw new Error('You have not reviewed this product');
    }

    if (rating !== undefined) {
        if (rating < 1 || rating > 5) throw new Error('Invalid rating');
        review.rating = Number(rating);
    }
    if (comment) review.comment = comment;

    // Recalculate average
    const total = product.reviews.reduce((acc, r) => acc + r.rating, 0);
    product.rating = Number((total / product.reviews.length).toFixed(1));
    product.numReviews = product.reviews.length;

    await product.save();

    res.json({ message: 'Review updated' });
};

// @desc    Delete a review (own or admin)
// @route   DELETE /api/products/:slug/reviews
// @access  Private (own review) or Admin
const deleteProductReview = async (req, res) => {
    const product = await Product.findOne({ slug: req.params.slug });
    if (!product) throw new Error('Product not found');

    const reviewIndex = product.reviews.findIndex(
        (r) => r.user.toString() === req.user._id.toString()
    );

    if (reviewIndex === -1 && req.user.role !== 'admin') {
        res.status(403);
        throw new Error('Not authorized');
    }

    if (reviewIndex !== -1) {
        product.reviews.splice(reviewIndex, 1);
    } else {
        // Admin deleting someone else's review
        const reviewToDelete = product.reviews.find(
            (r) => r._id.toString() === req.body.reviewId // pass reviewId in body
        );
        if (!reviewToDelete) throw new Error('Review not found');
        product.reviews = product.reviews.filter(r => r._id.toString() !== req.body.reviewId);
    }

    // Recalculate
    if (product.reviews.length > 0) {
        const total = product.reviews.reduce((acc, r) => acc + r.rating, 0);
        product.rating = Number((total / product.reviews.length).toFixed(1));
        product.numReviews = product.reviews.length;
    } else {
        product.rating = 0;
        product.numReviews = 0;
    }

    await product.save();

    res.json({ message: 'Review removed' });
};

// @desc    Create a new product
// @route   POST /api/products
// @access  Private/Admin
const createProduct = async (req, res) => {
    const {
        name,
        description,
        price,
        discountPrice,
        countInStock,
        image,
        images,
        category,
        brand,
    } = req.body;

    const product = new Product({
        name,
        description,
        price,
        discountPrice: discountPrice || 0,
        countInStock,
        image,
        images: images || [],
        category,
        brand,
        createdBy: req.user._id, //from protect middleware
    });

    let imagePath = '';
    if (req.file) {
        imagePath = `/uploads/${req.file.filename}`;
    }
    // then use imagePath in product creation

    const createdProduct = await product.save();
    res.status(200).json(createdProduct);

}

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private/Admin
const updateProduct = async (req, res) => {
    const product = await Product.findById(req.params.id);

    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    product.name = req.body.name || product.name;
    product.description = req.body.description || product.description;
    product.price = req.body.price || product.price;
    product.discountPrice = req.body.discountPrice !== undefined ? req.body.discountPrice : product.discountPrice;
    product.countInStock = req.body.countInStock || product.countInStock;
    product.image = req.body.image || product.image;
    product.images = req.body.images || product.images;
    product.category = req.body.category || product.category;
    product.brand = req.body.brand || product.brand;

    const updatedProduct = await product.save();
    res.json(updatedProduct);
};

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private/Admin
const deleteProduct = async (req, res) => {
    const product = await Product.findById(req.params.id);

    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    await product.deleteOne();
    res.json({ message: 'Product removed' });
};

// @desc    Toggle featured status of a product
// @route   PATCH /api/products/:slug/featured
// @access  Private/Admin
const toggleFeatured = async (req, res) => {
    const product = await Product.findOne({ slug: req.params.slug });

    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    product.isFeatured = !product.isFeatured;
    await product.save();

    res.json({
        success: true,
        message: `Product is now ${product.isFeatured ? 'featured' : 'not featured'}`,
        isFeatured: product.isFeatured,
    });
};


module.exports = {
    getProducts,
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleFeatured,
    createProductReview,
    updateProductReview,
    deleteProductReview,
    getProductReviews,
};