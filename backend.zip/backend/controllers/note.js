// @desc    Get all products (public) with skill skip pagination
// @route   GET /api/products
// @access  Public
const getProducts = async (req, res) => {
    const page = Number(req.query.pageNumber) || 1;          // current page, default 1
    const pageSize = Number(req.query.pageSize) || 12;       // items per page, default 12 (good for grids)

    // Optional: keyword search (e.g. ?keyword=wireless)
    const keyword = req.query.keyword
        ? {
            name: {
                $regex: req.query.keyword,
                $options: 'i', // case-insensitive
            },
        }
        : {};

    // Optional: category filter (e.g. ?category=Electronics)
    if (req.query.category) {
        keyword.category = req.query.category;
    }

    // Count total matching documents (for frontend pagination UI)
    const count = await Product.countDocuments({ ...keyword });

    // Fetch paginated products
    const products = await Product.find({ ...keyword })
        .sort({ createdAt: -1 })              // newest first (you can change to price, rating, etc.)
        .limit(pageSize)
        .skip(pageSize * (page - 1));         // skip previous pages


    res.json({
        products,
        page,                                 // current page
        pages: Math.ceil(count / pageSize),   // total pages
        totalProducts: count,                 // total matching items
    });
};


// @desc    Get products with cursor-based pagination (for infinite scroll / load more) without price range
// @route   GET /api/products
// @access  Public
const getProductsC = async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 12;
    const cursor = req.query.cursor || null;
    const sort = req.query.sort || 'newest'; // options: newest, price-asc, price-desc, rating

    // Filters
    const keyword = req.query.keyword
      ? { name: { $regex: req.query.keyword, $options: 'i' } }
      : {};
    const category = req.query.category ? { category: req.query.category } : {};

    const query = { ...keyword, ...category };

    // Determine sort direction and field
    let sortField = '_id';
    let sortOrder = -1; // descending (newest first)

    switch (sort) {
      case 'price-asc':
        sortField = 'price';
        sortOrder = 1;
        break;
      case 'price-desc':
        sortField = 'price';
        sortOrder = -1;
        break;
      case 'rating':
        sortField = 'rating';
        sortOrder = -1;
        break;
      case 'newest':
      default:
        sortField = '_id';
        sortOrder = -1;
        break;
    }

    // Build sort object
    const sortObj = { [sortField]: sortOrder, _id: sortOrder }; // tie-breaker on _id same direction

    // Cursor decoding (format: base64(`${value}|${_id}`) where value = sortField value)
    let cursorValue = null;
    let cursorId = null;

    if (cursor) {
      const decoded = Buffer.from(cursor, 'base64').toString('utf-8');
      const [val, id] = decoded.split('|');
      cursorValue = sortField === '_id' ? id : Number(val); // price/rating are numbers
      cursorId = id;
    }

    // Build range condition for cursor
    if (cursor) {
      if (sortField === '_id') {
        query._id = sortOrder === -1 ? { $lt: cursorValue } : { $gt: cursorValue };
      } else {
        // For non-unique fields: (sortField > cursorValue) OR (sortField == cursorValue AND _id >/< cursorId)
        const rangeOp = sortOrder === 1 ? '$gt' : '$lt';
        const tieOp = sortOrder === 1 ? '$gt' : '$lt';

        query.$or = [
          { [sortField]: { [rangeOp]: cursorValue } },
          {
            [sortField]: cursorValue,
            _id: { [tieOp]: cursorId },
          },
        ];
      }
    }

    // Fetch next batch (+1 to detect more)
    let products = await Product.find(query)
      .sort(sortObj)
      .limit(limit + 1)
      .lean(); // lean for plain objects (faster)

    // Pagination metadata
    let hasNextPage = products.length > limit;
    let nextCursor = null;

    if (hasNextPage) {
      const last = products.pop(); // remove extra
      const lastSortValue = sortField === '_id' ? last._id.toString() : last[sortField];
      const composite = `${lastSortValue}|${last._id.toString()}`;
      nextCursor = Buffer.from(composite).toString('base64');
    }

    // Optional total (can be expensive on large filtered sets – consider caching or removing)
    const total = await Product.countDocuments({ ...keyword, ...category });

    res.json({
      products,
      nextCursor,
      hasNextPage,
      total,           // total matching after filters (not paginated)
      currentSort: sort,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: 'Failed to fetch products' });
  }
};