const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Cart = require('../models/Cart');
const generateToken = require('../utils/generateToken');


// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        res.status(400);
        throw new Error('Please fill all required fields');
    }

    const userExists = await User.findOne({ email });

    if (userExists) {
        res.status(400);
        throw new Error('User already exists');
    }

    const user = await User.create({
        name,
        email,
        password,
        role: email === 'admin@example.com' ? 'admin' : 'user', // ← temp for testing
    });

    if (user) {
        res.status(201).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            token: generateToken(user._id),
        });
    } else {
        res.status(400);
        throw new Error('Invaild user data');
    }
});

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
const loginUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    // 1. Input validation
    if (!email || !password) {
        res.status(400);
        throw new Error('Email and password are required');
    }

    // 2. Find user with password
    const user = await User.findOne({ email }).select('+password');

    // 3. Verify credentials
    if (!user || !(await user.matchPassword(password))) {
        res.status(401);
        throw new Error('Invalid email or password');
    }

    // 4. Merge guest cart (session-based) into user cart
    const sessionId = req.session?.id;

    if (sessionId) {
        const guestCart = await Cart.findOne({ sessionId });

        if (guestCart && guestCart.items.length > 0) {
            let userCart = await Cart.findOne({ user: user._id });

            if (!userCart) {
                userCart = await Cart.create({ user: user._id, items: [] });
            }

            // Merge logic
            for (const guestItem of guestCart.items) {
                const existing = userCart.items.find(
                    (i) => i.product.toString() === guestItem.product.toString()
                );

                if (existing) {
                    existing.quantity += guestItem.quantity;
                    // Optional: cap at stock (requires product lookup)
                    // const product = await Product.findById(guestItem.product);
                    // if (existing.quantity > product.countInStock) {
                    //   existing.quantity = product.countInStock;
                    // }
                } else {
                    userCart.items.push({
                        product: guestItem.product,
                        quantity: guestItem.quantity,
                        priceAtAdd: guestItem.priceAtAdd,
                    });
                }
            }

            await userCart.save();

            // Clean up guest session cart
            await Cart.deleteOne({ sessionId });

            // Optional: log for debugging (remove in production)
            console.log(`Merged ${guestCart.items.length} guest items into user cart for ${user.email}`);
        }
    }

    // 5. Optional: populate user cart if you want to return it immediately
    // const userCart = await Cart.findOne({ user: user._id })
    //   .populate('items.product', 'name price image slug countInStock');

    // 6. Successful response
    res.json({
        success: true,
        user: {
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
        },
        token: generateToken(user._id),
        // cart: userCart || { items: [], subtotal: 0, total: 0 }, // optional
    });
});

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
    // req.user is already set by protect middleware
    res.status(200).json({
        _id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        role: req.user.role,
        createdAt: req.user.createdAt,
    })
}


module.exports = { registerUser, loginUser, getMe };