const asyncHandler = require('express-async-handler');
const Cart = require('../models/Cart');
const Order = require('../models/Order');
const Product = require('../models/Product');
const { paypalClient } = require('../utils/paypal');
const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// @desc    Create new order from cart
// @route   POST /api/orders
// @access  Private
const createOrder = asyncHandler(async (req, res) => {
    const { shippingAddress, paymentMethod } = req.body;

    // Validate input
    if (!shippingAddress || !paymentMethod) {
        res.status(400);
        throw new Error('Shipping address and payment method are required');
    }

    // Get user's cart
    const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');

    if (!cart || cart.items.length === 0) {
        res.status(400);
        throw new Error('Cart is empty');
    }

    // Calculate prices
    const itemsPrice = cart.items.reduce(
        (acc, item) => acc + item.quantity * item.priceAtAdd,
        0
    );
    const shippingPrice = itemsPrice > 100 ? 0 : 10; // example free shipping over $100
    const taxPrice = Number((itemsPrice * 0.15).toFixed(2)); // 15% tax example
    const totalPrice = itemsPrice + shippingPrice + taxPrice;

    // Create order items with snapshots
    const orderItems = cart.items.map(item => ({
        product: item.product._id,
        name: item.product.name,
        quantity: item.quantity,
        image: item.product.image,
        priceAtPurchase: item.priceAtAdd,
    }));

    // Create order
    const order = await Order.create({
        user: req.user._id,
        orderItems,
        shippingAddress,
        paymentMethod,
        itemsPrice,
        shippingPrice,
        taxPrice,
        totalPrice,
    });

    // Clear cart after order creation
    cart.items = [];
    await cart.save();

    res.status(201).json(order);
});


// @desc    Create Stripe Payment Intent
// @route   POST /api/orders/:id/pay
// @access  Private
const createPaymentIntent = asyncHandler(async (req, res) => {
    const order = await Order.findById(req.params.id);

    if (!order) {
        res.status(404);
        throw new Error('Order not found');
    }

    if (order.user.toString() !== req.user._id.toString()) {
        res.status(403);
        throw new Error('Not authorized');
    }

    if (order.isPaid) {
        res.status(400);
        throw new Error('Order already paid');
    }

    const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(order.totalPrice * 100), // cents
        currency: 'usd',
        metadata: { orderId: order._id.toString() },
    });

    res.json({
        clientSecret: paymentIntent.client_secret,
    });
});



// Create PayPal order
const createPaypalOrder = asyncHandler(async (req, res) => {
    const order = await Order.findById(req.params.id);

    if (!order) throw new Error('Order not found');
    if (order.user.toString() !== req.user._id.toString()) {
        res.status(403);
        throw new Error('Not authorized');
    }
    if (order.isPaid) throw new Error('Order already paid');

    const request = new checkoutNodeJssdk.orders.OrdersCreateRequest();
    request.requestBody({
        intent: 'CAPTURE',
        purchase_units: [{
            amount: {
                currency_code: 'USD',
                value: order.totalPrice.toFixed(2),
            },
            description: `Order #${order._id}`,
        }],
        application_context: {
            return_url: 'http://localhost:3000/order-success', // your frontend success page
            cancel_url: 'http://localhost:3000/order-cancel',
        },
    });

    const response = await paypalClient().execute(request);

    res.json({
        id: response.result.id, // send this to frontend to render PayPal buttons
    });
});


const capturePaypalOrder = asyncHandler(async (req, res) => {
    const { orderId, paypalOrderId } = req.body;

    const order = await Order.findById(orderId);
    if (!order || order.user.toString() !== req.user._id.toString()) {
        res.status(403);
        throw new Error('Not authorized');
    }

    const request = new checkoutNodeJssdk.orders.OrdersCaptureRequest(paypalOrderId);
    const response = await paypalClient().execute(request);

    if (response.result.status === 'COMPLETED') {
        order.isPaid = true;
        order.paidAt = Date.now();
        order.paymentResult = {
            id: response.result.id,
            status: response.result.status,
            paypalOrderId,
        };
        await order.save();

        res.json({ success: true, order });
    } else {
        res.status(400);
        throw new Error('Payment capture failed');
    }
});


module.exports = { createOrder, createPaymentIntent, createPaypalOrder, capturePaypalOrder };