const asyncHandler = require('express-async-handler');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const logger = require('../config/logger');


// Helper function
const getOrCreateCart = async (req) => {
    const isGuest = !req.user;
    const id = isGuest ? req.session?.id : req.user?._id;
    const sessionId = req.session?.id;

    logger.debug(`Fetching cart for ${isGuest ? 'guest' : 'user'} → ID: ${id}`);
    

    if (!req.user && sessionId && !req.session.cartLogged) {
        console.log('[getOrCreateCart] Guest session active:', sessionId);
        req.session.cartLogged = true; // flag so it only logs once per session
    }

    let cart;

    if (req.user) {
        cart = await Cart.findOne({ user: req.user._id });
        if (!cart) {
            cart = await Cart.create({ user: req.user._id, items: [] });
            console.log('[getOrCreateCart] Created new USER cart:', cart._id);
        }
    } else {
        const sessionId = req.session?.id;
        if (!sessionId) {
            throw new Error('No session ID available for guest');
        }

        cart = await Cart.findOne({ sessionId });
        if (!cart) {
            cart = await Cart.create({ sessionId, items: [] });
            console.log('[getOrCreateCart] Created new GUEST cart:', cart._id, 'for session:', sessionId);
        }
    }

    return cart;
};

// @desc    Get user's cart
// @route   GET /api/cart
// @access  Private
const getCart = async (req, res) => {
    const cart = await getOrCreateCart(req);
    await cart.populate('items.product', 'name price image slug countInStock');

    // NEW: Calculate totals
    const subtotal = cart.items.reduce(
        (acc, item) => acc + item.quantity * item.priceAtAdd,
        0
    );

    res.json({
        ...cart.toObject(),
        subtotal: Number(subtotal.toFixed(2)),
        // You can add shipping/tax later here
        total: Number(subtotal.toFixed(2)), // for now same as subtotal
    });
};

// @desc    Add item to cart
// @route   POST /api/cart
// @access  Private
const addToCart = asyncHandler(async (req, res) => {
    const { productId, quantity = 1 } = req.body;

    logger.debug(`Adding ${quantity}x product ${productId} for ${req.user ? 'user' : 'guest'}`);

    // Validate productId
    if (!productId) {
        res.status(400);
        throw new Error('Product ID is required');
    }

    // Fetch product
    const product = await Product.findById(productId);
    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    // Stock check
    const qty = Number(quantity);
    if (isNaN(qty) || qty < 1) {
        res.status(400);
        throw new Error('Quantity must be a positive integer');
    }

    if (product.countInStock < qty) {
        res.status(400);
        throw new Error(`Only ${product.countInStock} in stock`);
    }

    // Get or create cart (guest or authenticated)
    const cart = await getOrCreateCart(req);

    // Check if product is already in cart
    const itemIndex = cart.items.findIndex(
        (item) => item.product.toString() === productId.toString()
    );

    if (itemIndex !== -1) {
        // Update existing item
        const newQty = cart.items[itemIndex].quantity + qty;
        if (newQty > product.countInStock) {
            res.status(400);
            throw new Error(`Cannot exceed stock: only ${product.countInStock} available`);
        }
        cart.items[itemIndex].quantity = newQty;
    } else {
        // Add new item
        cart.items.push({
            product: productId,
            quantity: qty,
            priceAtAdd: product.price, // price snapshot
        });
    }

    // Save changes
    await cart.save();

    // Populate product details for response
    await cart.populate('items.product', 'name price image slug countInStock');

    // Calculate totals
    const subtotal = cart.items.reduce(
        (acc, item) => acc + item.quantity * item.priceAtAdd,
        0
    );

    logger.info(
        {
            cartId: cart._id.toString(),
            itemsAdded: quantity,
            newItemCount: cart.items.length,
            subtotal: totals.subtotal,
        },
        'Item added to cart'
    );

    // Response
    res.status(201).json({
        success: true,
        message: 'Item added to cart',
        cart: cart.toObject(),
        subtotal: Number(subtotal.toFixed(2)),
        total: Number(subtotal.toFixed(2)), // expand later with tax/shipping
    });
});


// @desc    Update cart item quantity
// @route   PUT /api/cart/:productId
// @access  Private
const updateCartItem = async (req, res) => {
    const { quantity } = req.body;

    if (!quantity || quantity < 1) {
        res.status(400);
        throw new Error('Quantity must be at least 1');
    }

    // Use helper → works for both logged-in and guest
    const cart = await getOrCreateCart(req);

    const itemIndex = cart.items.findIndex(
        (item) => item.product.toString() === req.params.productId
    );

    if (itemIndex === -1) {
        res.status(404);
        throw new Error('Item not found in cart');
    }

    const product = await Product.findById(req.params.productId);
    if (!product) {
        res.status(404);
        throw new Error('Product not found');
    }

    if (quantity > product.countInStock) {
        res.status(400);
        throw new Error(`Only ${product.countInStock} in stock`);
    }

    cart.items[itemIndex].quantity = Number(quantity);

    await cart.save();

    // Repopulate product details
    await cart.populate('items.product', 'name price image slug countInStock');

    // Calculate subtotal & total
    const subtotal = cart.items.reduce(
        (acc, item) => acc + item.quantity * item.priceAtAdd,
        0
    );

    res.json({
        ...cart.toObject(),
        subtotal: Number(subtotal.toFixed(2)),
        total: Number(subtotal.toFixed(2)), // add tax/shipping here later if needed
    });
};

// @desc    Remove item from cart
// @route   DELETE /api/cart/:productId
// @access  Private
const removeFromCart = async (req, res) => {
    const cart = await getOrCreateCart(req);

    const initialLength = cart.items.length;

    cart.items = cart.items.filter(
        (item) => item.product.toString() !== req.params.productId
    );

    if (cart.items.length === initialLength) {
        res.status(404);
        throw new Error('Item not found in cart');
    }

    await cart.save();

    // Repopulate
    await cart.populate('items.product', 'name price image slug countInStock');

    // Calculate totals
    const subtotal = cart.items.reduce(
        (acc, item) => acc + item.quantity * item.priceAtAdd,
        0
    );

    res.json({
        ...cart.toObject(),
        subtotal: Number(subtotal.toFixed(2)),
        total: Number(subtotal.toFixed(2)),
    });
};

// @desc    Clear entire cart
// @route   DELETE /api/cart
// @access  Private
const clearCart = async (req, res) => {
    const cart = await getOrCreateCart(req);

    cart.items = [];

    await cart.save();

    // No need to populate since cart is now empty
    res.json({
        message: 'Cart cleared successfully',
        items: [],
        subtotal: 0,
        total: 0,
    });
};



module.exports = {
    getCart,
    addToCart,
    updateCartItem,
    removeFromCart,
    clearCart,
};