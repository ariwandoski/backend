const express = require('express');
const router = express.Router();
const { 
    registerUser, 
    loginUser, 
    getMe,
 } = require('../controllers/authController');

const { protect, admin } = require('../middleware/authMiddleware');

//Public routes
router.post('/register', registerUser);
router.post('/login', loginUser);

// Protected routes
router.get('/me', protect, getMe);


// Admin-only test route
router.get('/admin-test', protect, admin, (req, res) => {
    res.status(200).json({
        message: 'Welcome to admin-only area',
        user: {
            id: req.user._id,
            name: req.user.name,
            role: req.user.role,
        },
    });
});

module.exports = router;