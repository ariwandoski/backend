const express = require('express');
const router = express.Router();

const {
    getProducts,
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct,
    toggleFeatured,
    createProductReview,
    updateProductReview,
    deleteProductReview,
    getProductReviews,
} = require('../controllers/productController');

const {protect, admin} = require('../middleware/authMiddleware');

// Public routes
router.get('/', getProducts);
//Changed :id to :slug for clarity
router.get('/:slug', getProductById);
router.get('/:slug/reviews', getProductReviews);

//User Routes (Protected + user check)
router.post('/:slug/reviews', protect, createProductReview);
router.patch('/:slug/reviews', protect, updateProductReview);
router.delete('/:slug/reviews', protect, deleteProductReview);


// Admin routes (protected + admin check)
router.post('/', protect, admin, createProduct);
router.put('/:id', protect, admin, updateProduct);
router.delete('/:id', protect, admin, deleteProduct);
router.patch('/:slug/featured', protect, admin, toggleFeatured);

module.exports = router;