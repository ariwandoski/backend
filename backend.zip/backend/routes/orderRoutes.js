const express = require('express');
const router = express.Router();

const {
    createOrder,
    createPaymentIntent,
    createPaypalOrder,
    capturePaypalOrder,
} = require('../controllers/orderController');
const { protect } = require('../middleware/authMiddleware');

// Protected routes
router.post('/', protect, createOrder);

router.post('/:id/pay', protect, createPaymentIntent);

router.post('/:id/paypal', protect, createPaypalOrder);

router.post('/:id/paypal/capture', protect, capturePaypalOrder);

module.exports = router;